<?php

class __Mustache_5d4df9fa9bdeaf5a84f6094de409ccff extends Mustache_Template
{
    public function renderInternal(Mustache_Context $context, $indent = '')
    {
        $buffer = '';

        $buffer .= $indent . '
';
        $buffer .= $indent . '<div
';
        $buffer .= $indent . '    class="hidden"
';
        $buffer .= $indent . '    data-region="view-contact"
';
        $buffer .= $indent . '    aria-hidden="true"
';
        $buffer .= $indent . '>
';
        $buffer .= $indent . '    <div class="p-2 pt-3" data-region="content-container"></div>
';
        $buffer .= $indent . '</div>';

        return $buffer;
    }
}

<?php
// ********** This file is generated DO NOT EDIT **********
$CFG->siteidentifier = 'pNn0RYVWEZ2CELtSsPr1uFUQzJ7vNh1Vlocalhost';
$CFG->bootstraphash = '454f3cd0b5db98bf7502027850a3015f';
// Only if the file is not stale and has not been defined.
if ($CFG->bootstraphash === hash_local_config_cache() && !defined('SYSCONTEXTID')) {
    define('SYSCONTEXTID', 1);
}
